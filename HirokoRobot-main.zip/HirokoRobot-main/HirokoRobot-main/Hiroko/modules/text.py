

SHORTENER_TEXT = """
**˹ʜɪꝛᴏᴋᴏ ꝛᴏʙᴏᴛ˼ ᴄᴏᴏʟ ᴏʀ ᴇxᴄʟᴜsɪᴠᴇ ғᴇᴀᴛᴜʀᴇs**

<code>ʜᴇʟʟᴏ ɢᴜʏꜱ ʜᴇʀᴇ ʟɪɴᴋ ꜱʜᴏʀᴛᴇɴᴇʀ ᴄᴏᴍᴍᴀɴᴅꜱ
ᴛʏᴘᴇ</code> <code>/shortener</code> 

<code>ᴇxᴀᴍᴘʟᴇ</code> :- <code>/shortener 9e057515d222131456b51729e54033ab4e1d6936 https://urlshortx.com/api? </code>
<code>
ʏᴏᴜ ᴄᴀɴ ᴄᴏɴɴᴇᴄᴛ ᴛᴏ ᴛʜᴇ ʙᴏᴛ'ꜱ ᴜʀʟ ꜱʜᴏʀᴛᴇɴᴇʀ
ꜱᴇʀᴠɪᴄᴇ. ʏᴏᴜ ᴄᴀɴ ꜱᴇɴᴅ ᴀɴʏ ʟɪɴᴋ ᴛᴏ ᴛʜᴇ ʙᴏᴛ, 
ᴀɴᴅ ɪᴛ ᴡɪʟʟ ᴄᴏɴᴠᴇʀᴛ ɪᴛ ɪɴᴛᴏ ᴀ ꜱʜᴏʀᴛᴇɴᴇᴅ ʟɪɴᴋ ꜰᴏʀ ʏᴏᴜ</code>
"""


ADMINS_TEXT = """
**˹ʜɪꝛᴏᴋᴏ ꝛᴏʙᴏᴛ˼ ᴄᴏᴏʟ ᴏʀ ᴇxᴄʟᴜsɪᴠᴇ ғᴇᴀᴛᴜʀᴇs**

» <code>/zombies</code> : <code>ʀᴇᴍᴏᴠᴇs ᴛʜᴇ ᴅᴇʟᴇᴛᴇᴅ ᴀᴄᴄᴏᴜɴᴛs ғʀᴏᴍ ᴛʜᴇ ɢʀᴏᴜᴘ.</code>

» <code>/pin</code> : <code>ᴘɪɴs ᴛʜᴇ ᴍᴇssᴀɢᴇ ʀᴇᴘʟɪᴇᴅ ᴛᴏ - ᴀᴅᴅ 'ʟᴏᴜᴅ' ᴏʀ 'ɴᴏᴛɪғʏ' ᴛᴏ ɢɪᴠᴇ ɴᴏᴛɪғʏ ᴛᴏ ᴜsᴇʀs.</code>

» <code>/unpin</code> : <code>ᴜɴᴘɪɴs ᴛʜᴇ ᴄᴜʀʀᴇɴᴛʟʏ ᴘɪɴɴᴇᴅ ᴍᴇssᴀɢᴇ.</code>

» <code>/purge</code> :  <code>ᴅᴇʟᴇᴛᴇs ᴀʟʟ ᴍᴇssᴀɢᴇs ʙᴇᴛᴡᴇᴇɴ ᴛʜɪs ᴀɴᴅ ᴛʜᴇ ʀᴇᴘʟɪᴇᴅ ᴛᴏ ᴍᴇssᴀɢᴇs.</code>

» <code>/setphoto</code> : <code>sᴇᴛs ᴛʜᴇ ʀᴇᴘʟɪᴇᴅ ɪᴍᴀɢᴇ/ᴅᴏᴄᴜᴍᴇɴᴛ ᴀs ᴛʜᴇ ɢʀᴏᴜᴘ ᴘɪᴄᴛᴜʀᴇ.</code>

» <code>/removephoto</code> : <code>ᴅᴇʟᴇᴛᴇs ᴛʜᴇ ɢʀᴏᴜᴘ ᴘɪᴄᴛᴜʀᴇ.</code>

» <code>/settitle</code> : <code>sᴇᴛs ᴛʜᴇ ɢʀᴏᴜᴘ ᴛɪᴛᴇʟ.</code>
"""


GITHUB_TEXT = """
**˹ʜɪꝛᴏᴋᴏ ꝛᴏʙᴏᴛ˼ ᴄᴏᴏʟ ᴏʀ ᴇxᴄʟᴜsɪᴠᴇ ғᴇᴀᴛᴜʀᴇs**

<code>ᴘʀᴏᴠɪᴅᴇs ʏᴏᴜ ɪɴғᴏʀᴍᴀᴛɪᴏɴ ᴀʙᴏᴜᴛ ᴀ ɢɪᴛʜᴜʙ ᴘʀᴏғɪʟᴇ</code>

» <code>/github</code> **<ᴜsᴇʀɴᴀᴍᴇ>** : <code>ɢᴇᴛ ɪɴғᴏʀᴍᴀᴛɪᴏɴ ᴀʙᴏᴜᴛ ᴀ ɢɪᴛʜᴜʙ ᴜsᴇʀ.</code>
"""


FUN_TEXT = """
**˹ʜɪꝛᴏᴋᴏ ꝛᴏʙᴏᴛ˼ ᴄᴏᴏʟ ᴏʀ ᴇxᴄʟᴜsɪᴠᴇ ғᴇᴀᴛᴜʀᴇs**

» <code>/dice</code> : <code>sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ᴅɪᴄᴇ ɴᴜᴍʙᴇʀ.</code>

» <code>/arrow</code> : <code>sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ᴀʀʀᴏᴡ.</code>

» <code>/goal</code> : <code>ᴇɴᴊᴏʏ ᴛʜᴇ ɢᴏᴀʟ ɢᴀᴍᴇ.</code>

» <code>/luck</code> : <code>ᴄʜᴇᴄᴋ ʏᴏᴜʀ ʟᴜᴄᴋ ɪɴ ᴛʜᴇ ɢᴀᴍᴇ.</code>

» <code>/throw</code> : <code>ᴇɴᴊᴏʏ ᴛʜᴇ ᴛʜʀᴏᴡ ɢᴀᴍᴇ.</code>

» <code>/bowling</code> : <code>ᴇɴᴊᴏʏɪɴɢ ᴛʜᴇ ʙᴏᴡʟɪɴɢ ɢᴀᴍᴇ.</code>

» <code>/react</code> ᴏʀ <code>/reaction</code> : <code>ʀᴇᴀᴄᴛ ᴡɪᴛʜ ᴀ ʀᴀɴᴅᴏᴍ ʀᴇᴀᴄᴛɪᴏɴ.</code> 

» <code>/aq</code> ᴏʀ <code>/animequotes</code> : <code>sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ᴀɴɪᴍᴇ ǫᴜᴏᴛᴇs.</code>
"""


MISC_TEXT = """
**˹ʜɪꝛᴏᴋᴏ ꝛᴏʙᴏᴛ˼ ᴄᴏᴏʟ ᴏʀ ᴇxᴄʟᴜsɪᴠᴇ ғᴇᴀᴛᴜʀᴇs**

» <code>/id</code> : <code>ɢᴇᴛ ᴛʜᴇ ᴄᴜʀʀᴇɴᴛ ɢʀᴏᴜᴘ ɪᴅ. ɪғ ᴜsᴇᴅ ʙʏ ʀᴇᴘʟʏɪɴɢ ᴛᴏ ᴀ ᴍᴇssᴀɢᴇ, ɢᴇᴛs ᴛʜᴀᴛ ᴜsᴇʀ's ɪᴅ.</code>

» <code>/info</code> : <code>ɢᴇᴛ ɪɴғᴏʀᴍᴀᴛɪᴏɴ ᴀʙᴏᴜᴛ ᴀ ᴜsᴇʀ.</code>

» <code>/tr</code> : <code>ᴛʀᴀɴsʟᴀᴛᴇ ᴛᴇxᴛ ᴡʀɪᴛᴛᴇɴ ᴏʀ ʀᴇᴘʟʏ ғᴏʀ ᴀɴʏ ʟᴀɴɢᴜᴀɢᴇ ᴛᴏ ᴛʜᴇ ɪɴᴛᴇɴᴇᴅ ʟᴀɴɢᴜᴀɢᴇ.</code>

» <code>/wiki</code> : <code>sᴇᴀʀᴄʜ ғᴏʀ ᴛᴇxᴛ ᴡʀɪᴛᴛᴇɴ ғʀᴏᴍ ᴛʜᴇ ᴡɪᴋɪᴘᴇᴅɪᴀ sᴏᴜʀᴄᴇ.</code>

» <code>/video</code> : <code>ɢᴇᴛ ᴠɪᴅᴇᴏ ғɪʟᴇ ғʀᴏᴍ ʏᴏᴜᴛᴜʙᴇ.</code>

» <code>/song</code> : <code>ɢᴇᴛ ᴀᴜᴅɪᴏ ғɪʟᴇ ғʀᴏᴍ ʏᴏᴜᴛᴜʙᴇ.</code>

» <code>/tg</code> ᴏʀ <code>/telegraph</code> : <code>ɢᴇᴛ ᴛᴇʟᴇɢʀᴀᴘʜ ʟɪɴᴋ ᴏʀ ʀᴇᴘʟɪᴇᴅ ᴍᴇᴅɪᴀ.</code>

» <code>/speedtest</code> : <code>ʀᴜɴs ᴀ sᴘᴇᴇᴅᴛᴇsᴛ ᴀɴᴅ ᴄʜᴇᴄᴋ ᴛʜᴇ sᴇʀᴠᴇʀ sᴘᴇᴇᴅ.</code>

» <code>/admins</code> ᴏʀ <code>/staff</code> : <code>ʟɪsᴛ ᴏғ ᴀᴅᴍɪɴs ɪɴ ᴛʜᴇ ᴄʜᴀᴛ.</code>

» <code>/bots</code> : <code>ʟɪsᴛ ᴏғ ᴛʜᴇ ʙᴏᴛs ɪɴ ᴛʜᴇ ᴄʜᴀᴛ</code>

"""


NEKOS_TEXT = """
**˹ʜɪꝛᴏᴋᴏ ꝛᴏʙᴏᴛ˼ ᴄᴏᴏʟ ᴏʀ ᴇxᴄʟᴜsɪᴠᴇ ғᴇᴀᴛᴜʀᴇs**

» <code>/cuddle</code> : <code>ʙᴏᴛ sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ᴄᴜᴅᴅʟᴇ ɢɪғ ᴏʀ ᴘʜᴏᴛᴏ.</code>

» <code>/bore</code> : <code>ʙᴏᴛ sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ʙᴏʀᴇ ɢɪғ ᴏʀ ᴘʜᴏᴛᴏ.</code>

» <code>/laugh</code> : <code>ʙᴏᴛ sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ʟᴀᴜɢʜ ɢɪғ ᴏʀ ᴘʜᴏᴛᴏ.</code>

» <code>/sleep</code> : <code>ʙᴏᴛ sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ sʟᴇᴇᴘ ɢɪғ ᴏʀ ᴘʜᴏᴛᴏ.</code>

» <code>/puch</code> : <code>ʙᴏᴛ sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ᴘᴜᴄʜ ɢɪғ ᴏʀ ᴘʜᴏᴛᴏ.</code>

» <code>/cry</code> : <code>ʙᴏᴛ sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ᴄʀʏ ɢɪғ ᴏʀ ᴘʜᴏᴛᴏ.</code>

» <code>/kill</code> : <code>ʙᴏᴛ sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ᴋɪʟʟ ɢɪғ ᴏʀ ᴘʜᴏᴛᴏ.</code>

» <code>/smile</code> : <code>ʙᴏᴛ sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ sᴍɪʟᴇ ɢɪғ ᴏʀ ᴘʜᴏᴛᴏ.</code>

» <code>/highfive</code> : <code>ʙᴏᴛ sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ʜɪɢʜғɪᴠᴇ ɢɪғ ᴏʀ ᴘʜᴏᴛᴏ.</code>

» <code>/slap</code> : <code>ʙᴏᴛ sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ sʟᴀᴘ ɢɪғ ᴏʀ ᴘʜᴏᴛᴏ.</code>

» <code>/hug</code> : <code>ʙᴏᴛ sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ʜᴜɢ ɢɪғ ᴏʀ ᴘʜᴏᴛᴏ.</code>

» <code>/pat</code> : <code>ʙᴏᴛ sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ᴘᴀᴛ ɢɪғ ᴏʀ ᴘʜᴏᴛᴏ.</code>

» <code>/waifu</code> : <code>ʙᴏᴛ sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ᴡᴀɪғᴜ ɢɪғ ᴏʀ ᴘʜᴏᴛᴏ.</code>

"""


GAMES_TEXT = """
**˹ʜɪꝛᴏᴋᴏ ꝛᴏʙᴏᴛ˼ ᴄᴏᴏʟ ᴏʀ ᴇxᴄʟᴜsɪᴠᴇ ғᴇᴀᴛᴜʀᴇs**

» <code>/bet</code> : <code>ʙᴇᴛ sᴏᴍᴇ ᴄᴏɪɴs</code>

» <code>/rewards</code> : <code>ɢᴇᴛ ʀᴇᴡᴀʀᴅs ғᴏʀ ғɪʀsᴛ ᴜsᴇʀs.</code>

» <code>/bonus</code> : <code>ɢᴇᴛ ᴡᴇᴇᴋʟʏ ʙᴏɴᴜs.</code>

» <code>/topusers</code> : <code>ɴᴏ. 1 ᴜsᴇʀ ᴡʜᴏ ɢᴇᴛ ᴍᴀxɪᴍᴜᴍ ᴘʀᴏғɪᴛs.</code>

» <code>/truth</code> : <code>sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ᴛʀᴜᴛʜ sᴛʀɪɴɢ.</code>

» <code>/dare</code> : <code>sᴇɴᴅ ᴀ ʀᴀɴᴅᴏᴍ ᴅᴀʀᴇ sᴛʀɪɴɢ.</code>
"""


CHATGPT_TEXT = """
**˹ʜɪꝛᴏᴋᴏ ꝛᴏʙᴏᴛ˼ ᴄᴏᴏʟ ᴏʀ ᴇxᴄʟᴜsɪᴠᴇ ғᴇᴀᴛᴜʀᴇs**

» <code>/ask</code> ᴏʀ <code>/chatgpt</code> : <code>ᴀsᴋ ʏᴏᴜʀ ǫᴜᴇsᴛɪᴏɴ ᴀɴᴅ ᴀɴʏ ǫᴜᴇʀʏ ᴄʜᴀᴛɢᴘᴛ sᴏʟᴠᴇᴅ ʏᴏᴜʀ ᴘʀᴏʙʟᴇᴍ.</code>

» <code>/bard</code> : <code>ᴀsᴋ ʏᴏᴜʀ ǫᴜᴇsᴛɪᴏɴ ᴀɴᴅ ǫᴜᴇʀʏ ɢᴏᴏɢʟᴇ ʙᴀʀᴅ sᴏʟᴠᴇ ʏᴏᴜʀ ᴘʀᴏʙʟᴇᴍ.</code>

» <code>/image</code> ᴏʀ <code>/generate</code> : <code>ᴄʜᴀᴛɢᴘᴛ ɢᴇɴᴇʀᴀᴛᴇ ʀᴀɴᴅᴏᴍ ɪᴍᴀɢᴇ.</code>
"""


CHATBOT_TEXT = """
**˹ʜɪꝛᴏᴋᴏ ꝛᴏʙᴏᴛ˼ ᴄᴏᴏʟ ᴏʀ ᴇxᴄʟᴜsɪᴠᴇ ғᴇᴀᴛᴜʀᴇs**

<code>/chatbot</code> : <code>ᴄʜᴀᴛʙᴏᴛ ᴇɴᴀʙʟᴇ/ᴅɪsᴀʙʟᴇ ᴄᴏᴍᴍᴀɴᴅ.</code>
"""


INSTATUS_TEXT = """
**˹ʜɪꝛᴏᴋᴏ ꝛᴏʙᴏᴛ˼ ᴄᴏᴏʟ ᴏʀ ᴇxᴄʟᴜsɪᴠᴇ ғᴇᴀᴛᴜʀᴇs**

**ʜᴇʀᴇ ɪs ɢʀᴏᴜᴘ ᴍᴇᴍʙᴇʀ ɪɴғᴏ ᴄᴏᴍᴍᴀɴᴅs.**

» <code>/instatus</code> : <code>ɢᴇᴛ ᴛʜᴇ sᴛᴀᴛᴜs ᴏғ ᴏᴜʀ ᴄʜᴀᴛ ᴍᴇᴍʙᴇʀs</code>
"""


AFK_TEXT = """
**˹ʜɪꝛᴏᴋᴏ ꝛᴏʙᴏᴛ˼ ᴄᴏᴏʟ ᴏʀ ᴇxᴄʟᴜsɪᴠᴇ ғᴇᴀᴛᴜʀᴇs**

soon
"""


ACTION_TEXT = """
**˹ʜɪꝛᴏᴋᴏ ꝛᴏʙᴏᴛ˼ ᴄᴏᴏʟ ᴏʀ ᴇxᴄʟᴜsɪᴠᴇ ғᴇᴀᴛᴜʀᴇs**

soon
"""



